import json, os, time, requests
from datetime import datetime, timezone, timedelta
from playwright.sync_api import sync_playwright

# Iraqi Timezone (UTC+3)
IQ_TZ = timezone(timedelta(hours=3))

# Telegram Bot Settings (Same bot used for your ticket monitor)
TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
TELEGRAM_CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "204598344").strip()

ACCOUNTS = []
if os.environ.get("FTTH_ALHIL_USER") and os.environ.get("FTTH_ALHIL_PASS"):
    ACCOUNTS.append({
        "code": "alhil",
        "username": os.environ["FTTH_ALHIL_USER"],
        "password": os.environ["FTTH_ALHIL_PASS"],
    })
if os.environ.get("FTTH_HLE_USER") and os.environ.get("FTTH_HLE_PASS"):
    ACCOUNTS.append({
        "code": "hle",
        "username": os.environ["FTTH_HLE_USER"],
        "password": os.environ["FTTH_HLE_PASS"],
    })


def send_telegram_alert(message: str):
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        return
    try:
        requests.post(
            f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage",
            json={"chat_id": TELEGRAM_CHAT_ID, "text": message, "parse_mode": "HTML"},
            timeout=15,
        )
    except Exception as e:
        print("Telegram alert error:", e)


def fetch_account_subscriptions(page, acct):
    print(f"🔐 جاري تسجيل الدخول لحساب الوكيل: {acct['code']}...")
    captured_subs = {}

    def on_response(res):
        try:
            if "subscriptions" in res.url and res.status == 200 and "application/json" in (res.headers.get("content-type") or ""):
                data = res.json()
                items = data.get("data") or data.get("items") or (data if isinstance(data, list) else [])
                if isinstance(items, list):
                    for item in items:
                        if isinstance(item, dict) and "hasActiveSession" in item and "customer" in item:
                            cid = str((item.get("customer") or {}).get("id") or "")
                            uname = str(item.get("username") or "").strip()
                            key = cid or uname
                            if key:
                                svcs = item.get("services") or []
                                svc_name = svcs[0].get("displayValue", "Basic") if svcs else "Basic"
                                captured_subs[key] = {
                                    "account": acct["code"],
                                    "subId": cid,
                                    "name": (item.get("customer") or {}).get("displayValue", ""),
                                    "username": uname,
                                    "status": item.get("status", "Inactive"),
                                    "isActive": item.get("status") == "Active",
                                    "hasActiveSession": bool(item.get("hasActiveSession")),
                                    "expires": str(item.get("expires") or "")[:10],
                                    "ipAddress": item.get("ipAddress") or ((item.get("activeSession") or {}).get("ipAddress") or ""),
                                    "serviceType": svc_name,
                                    "zone": (item.get("zone") or {}).get("displayValue", ""),
                                }
        except Exception:
            pass

    page.on("response", on_response)
    page.goto("https://admin.ftth.iq/login", wait_until="networkidle", timeout=60000)

    # Fill login form
    page.locator('input[type="text"], input[formcontrolname="username"], input[name="username"]').first.fill(acct["username"])
    page.locator('input[type="password"], input[formcontrolname="password"], input[name="password"]').first.fill(acct["password"])
    page.locator('button[type="submit"]').first.click()
    page.wait_for_timeout(4500)

    # Navigate to Subscriptions list (All statuses so we capture Active + Expired + Newly Changed)
    page.goto("https://admin.ftth.iq/subscriptions", wait_until="networkidle", timeout=60000)
    page.wait_for_timeout(3500)

    # Paginate through all pages
    page_num = 1
    while page_num <= 40:
        next_btn = page.locator('button.mat-paginator-navigation-next, [aria-label*="Next"], [aria-label*="التالي"]').first
        if next_btn.count() == 0 or next_btn.is_disabled():
            break
        next_btn.click()
        page.wait_for_timeout(1800)
        page_num += 1

    page.remove_listener("response", on_response)
    print(f"✅ تم سحب {len(captured_subs)} مشترك من حساب {acct['code']}")
    return list(captured_subs.values())


def main():
    if not ACCOUNTS:
        print("❌ لم يتم العثور على بيانات تسجيل الدخول (FTTH_ALHIL_USER / FTTH_HLE_USER) في إعدادات GitHub Secrets!")
        return

    # Load previous snapshot to detect changes
    prev_map = {}
    if os.path.exists("live_sync.json"):
        try:
            with open("live_sync.json", "r", encoding="utf-8") as f:
                prev_data = json.load(f)
                for s in prev_data.get("subscribers", []):
                    prev_map[f"{s.get('account')}:{s.get('username')}"] = s
        except Exception:
            pass

    all_subs = []
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        for acct in ACCOUNTS:
            context = browser.new_context()
            page = context.new_page()
            try:
                subs = fetch_account_subscriptions(page, acct)
                all_subs.extend(subs)
            except Exception as e:
                print(f"⚠️ خطأ أثناء سحب حساب {acct['code']}: {e}")
            finally:
                context.close()
        browser.close()

    if not all_subs:
        print("⚠️ لم يتم سحب أي مشتركين في هذه الدورة.")
        return

    newly_activated = []
    newly_expired = []

    for s in all_subs:
        k = f"{s['account']}:{s['username']}"
        old = prev_map.get(k)
        s["newlyActivated"] = False
        s["newlyExpired"] = False
        if old:
            if not old.get("isActive") and s["isActive"]:
                s["newlyActivated"] = True
                newly_activated.append(s)
            elif old.get("isActive") and not s["isActive"]:
                s["newlyExpired"] = True
                newly_expired.append(s)

    now_iq = datetime.now(IQ_TZ).strftime("%Y-%m-%d %H:%M")
    out = {
        "syncedAt": now_iq,
        "totalCount": len(all_subs),
        "activeCount": sum(1 for x in all_subs if x["isActive"]),
        "expiredCount": sum(1 for x in all_subs if not x["isActive"]),
        "newlyActivatedCount": len(newly_activated),
        "newlyExpiredCount": len(newly_expired),
        "subscribers": all_subs,
    }

    with open("live_sync.json", "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)

    print(f"🎉 اكتملت المزامنة ({now_iq}): {out['activeCount']} شغال | {out['expiredCount']} منتهي | 🆕 {len(newly_activated)} مفعل حديثاً | 🔴 {len(newly_expired)} منتهي حديثاً")

    # Send Telegram Notification if there are new activations or expirations
    if newly_activated or newly_expired:
        lines = [f"📡 <b>تحديث تلقائي — رادار FTTH IQ ({now_iq})</b>"]
        if newly_activated:
            lines.append(f"\n🟢 <b>تم تفعيل / تجديد ({len(newly_activated)} مشترك):</b>")
            for x in newly_activated[:10]:
                lines.append(f"• {x['name']} (<code>{x['username']}</code>) [{x['account']}]")
        if newly_expired:
            lines.append(f"\n🔴 <b>انتهى اشتراكهم الآن ({len(newly_expired)} مشترك):</b>")
            for x in newly_expired[:10]:
                lines.append(f"• {x['name']} (<code>{x['username']}</code>) [{x['account']}]")
        send_telegram_alert("\n".join(lines))


if __name__ == "__main__":
    main()
